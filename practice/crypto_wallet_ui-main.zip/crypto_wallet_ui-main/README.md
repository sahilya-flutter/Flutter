# crypto_wallet_ui

This project is just a design project for a crypto wallet app made in Flutter

Full video code : https://www.youtube.com/@flutterguys/videos

Project inspired by: https://www.figma.com/community/file/1139401010100518801/crypto-wallet-app-community

Linkedin : https://www.linkedin.com/in/fabrice-sumsa/

Music : Didi B, Widgunz - Giga de Cali




https://github.com/Fabrice-Fabio/crypto_wallet_ui/assets/35635121/9a12f920-6ad9-4691-bccf-9a82b18dca60





