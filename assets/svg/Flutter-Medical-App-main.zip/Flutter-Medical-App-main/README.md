# Medical App

📺 Watch Video

[YouTube video](https://youtu.be/4IcRN3C6TZ4) where the source code is explained. [Subscribe YouTube channel](https://www.youtube.com/channel/UCkSbTj3XSWdaGfHiITheBqg).
