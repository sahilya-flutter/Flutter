import 'package:flutter/material.dart';

class AppColors {
  
  static const primary = Color(0xffE21221);
  static const background = Color(0xff1D1E22);
  static const secondBackground = Color(0xff181A20);
}