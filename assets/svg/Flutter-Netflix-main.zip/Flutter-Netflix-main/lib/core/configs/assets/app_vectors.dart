class AppVectors {

  static const basePath = 'assets/vectors/';

  static const logo = '${basePath}logo.svg';
}